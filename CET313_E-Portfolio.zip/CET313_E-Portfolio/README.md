# Spam Detection System
**CET313 Artificial Intelligence Assignment**

## Contents
- `Code/spam_detection.ipynb`: Complete working notebook
- `Results/`: All output visualizations
- `Documentation/Report.pdf`: Full technical report

## Results Summary
| Model | Accuracy |
|-------|----------|
| Random Forest | 98.2% |
| LSTM | 99.1% |

![Confusion Matrix](Results/confusion_matrix.png)